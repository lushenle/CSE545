from scapy.all import L3RawSocket, conf, RandShort, send
from scapy.layers.inet import IP, UDP


def send_and_receive(dest_ip, dest_port, src_ip, payload):
    if dest_ip in ("127.0.0.1", "localhost"):
        conf.L3socket = L3RawSocket

    ip = IP(dst=dest_ip, src=src_ip)
    udp = UDP(sport=RandShort(), dport=dest_port)
    ans = send(ip/udp/str(payload), verbose=True)
    print(ans)


send_and_receive("udpspoof_cn.cse545.io", 13337, "10.2.4.10", "172.16.20.7")
